package com.hobis.works.job150621;

/**
 * Created by Hobis-PC on 2015-06-21.
 */
@SuppressWarnings("unused")
public class UserItem {

}
